# WebCam-Face-Emotion-Detection-Streamlit
Real time face detection streamlit based bew application for server deployment.
