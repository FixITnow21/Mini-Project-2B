package com.example.mobileapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
