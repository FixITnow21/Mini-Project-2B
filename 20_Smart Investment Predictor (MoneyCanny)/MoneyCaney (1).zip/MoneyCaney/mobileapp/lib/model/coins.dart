class CoinsModel {
  String? name;
  String? risk;
  double? predict;
  double? Current;


  CoinsModel(
      {this.name, this.predict,this.risk,this.Current});

  factory CoinsModel.fromJson(dynamic json) {
    return CoinsModel(
      name: "${json['Name']}",
      predict: json['Predict'],
      risk: "${json['Risk']}",
      Current: json['Current']
    );
  }

  Map toJson() => {
    "Name": name,
    "Predict": predict,
    "Risk": risk,
    "Current":Current
  };
}