import 'dart:convert' as convert;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobileapp/model/index_model.dart';
import 'package:mobileapp/model/coins.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mobileapp/model/user_model.dart';
import 'login_screen.dart';


class IndexPage extends StatefulWidget {
  const IndexPage({Key? key}) : super(key: key);

  @override
  _IndexPageState createState() => _IndexPageState();
}

class _IndexPageState extends State<IndexPage> {
  User? user=FirebaseAuth.instance.currentUser;
  UserModel loggedInUser =UserModel();
  IndexModel indexs = IndexModel();
  List<CoinsModel> coins = [];
  List<CoinsModel> new_coins = [];
  List<CoinsModel> shares = [];
  List<CoinsModel> new_shares = [];
  bool isSearching=false;


  @override
  void initState(){
    super.initState();

    http
        .get(Uri.parse(
        'https://script.google.com/macros/s/AKfycbyKCZp3MG-GRpxbHHz8JcFqaFWVkU9ZQvV5-MQP_mjdZ51H2d_6I0-kH-KaR4KG4hqL/exec'))
        .then((value) {

      convert.jsonDecode(value.body).forEach((element) {
        CoinsModel sharesModel = new CoinsModel();
        sharesModel.name = element['Name'];
        sharesModel.predict = element['Predict'];
        sharesModel.risk = element['Risk'];
        sharesModel.Current = element['Current'];
        this.shares.add(sharesModel);
      });
      this.new_shares=shares;
    });

    http
        .get(Uri.parse(
        'https://script.google.com/macros/s/AKfycbyeHRXy6aktiOiBx-j5or_ec2wi19WWD5X2OX8pCobrkG4SAl5X_NNzRhAnsrGSdPlH/exec'))
        .then((value) {
      convert.jsonDecode(value.body).forEach((element) {
        CoinsModel coinsModel = new CoinsModel();
        coinsModel.name = element['Name'];
        coinsModel.predict = element['Predict'];
        coinsModel.risk = element['Risk'];
        this.coins.add(coinsModel);
      });
    });


    http
        .get(Uri.parse(
            'https://script.google.com/macros/s/AKfycbxu4WFE2wcqFBnEXCjUnBMOE1V0L-CDPt2ZATFHqHEVOG1242h_2eNctQZC4VNDBhs4Iw/exec'))
        .then((value) {
      this.indexs = IndexModel.fromMap(convert.jsonDecode(value.body));
      FirebaseFirestore.instance
          .collection("users")
          .doc(user!.uid)
          .get()
          .then((value){
        this.loggedInUser = UserModel.fromMap(value.data());
        setState((){
          print("His Choice");
          print(loggedInUser.choice);
        });
      });
      setState(() {});
    });



  }

  void _new_shares(value) {
    setState(() {
      new_shares = shares.where((share) => share.Current!<double.parse(value)).toList();
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      drawer: Drawer(
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
                decoration: BoxDecoration(
                ),
                child: Row(
                    children:[
                      Text("Welcome "),
                      SizedBox(
                        height: 20,
                      ),
                      Text(loggedInUser.username!),
                    ]
                )
            ),
            ListTile(
              title: const Text('Index'),
              onTap: () {
                // Update the state of the app
                // ...
                // Then close the drawer
                Navigator.push(context, MaterialPageRoute(builder: (context)=> IndexPage()));
              },
            ),
            ListTile(
              title: const Text('Save'),
              onTap: () {
                // Update the state of the app
                // ...
                // Then close the drawer
                Navigator.pop(context);
              },
            ),
            SizedBox(
              height: 370,
            ),
            ListTile(
              title: const Text('Logout'),
              onTap: () {
                // Update the state of the app
                // ...
                // Then close the drawer
                logout(context);
              },
            ),
          ],
        ),
      ),
      body: Column(
        children:[
      SizedBox(
        height: 50,
      child:CustomScrollView(
            primary: true,
            slivers: <Widget>[
              SliverAppBar(
                title: !isSearching
                    ? GestureDetector(
                  onTap: () {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return Container(
                              height: 15,
                              child: AlertDialog(
                                  content: SizedBox(
                                      height: 70,
                                      child: Column(
                                        children: [
                                          Row(children: [
                                            Text("Todays Sensex can go :"),
                                            SizedBox(width: 15,),
                                            Text((indexs.Sensex.toString())+"%"),
                                          ],),
                                          Row(children: [
                                            Text("Todays IC15 can go :"),
                                            SizedBox(width: 15,),
                                            Text(indexs.Crypto.toString()+"%"),
                                          ],),
                                          Row(children: [
                                            Text("Todays Gold Price can go :"),
                                            SizedBox(width: 15,),
                                            Text(indexs.Gold.toString()+"%"),
                                          ],),
                                        ],
                                      ))));
                        });
                  },
                  child: Row(
                    children: [
                      Image(
                        height:  MediaQuery.of(context).size.height*0.1,
                        width: MediaQuery.of(context).size.width*0.1,
                        image: AssetImage(indexs.Sensex! > 1
                            ? "sensex_g.png"
                            : (indexs.Sensex! < -1
                            ? "sensex_r.png"
                            : "sensex.png")),
                      ),
                      Image(
                        height:  MediaQuery.of(context).size.height*0.1,
                        width: MediaQuery.of(context).size.width*0.1,
                        image: AssetImage(indexs.Crypto! > 2
                            ? "crypto_g.png"
                            : (indexs.Crypto! < -2
                            ? "crypto_r.png"
                            : "crypto.png")),
                      ),
                      Image(
                        height:  MediaQuery.of(context).size.height*0.1,
                        width: MediaQuery.of(context).size.width*0.1,
                        image: AssetImage(indexs.Gold! > 0.75
                            ? "gold_g.png"
                            : (indexs.Gold! < -0.75 ? "gold_r.png" : "gold.png")),
                      ),
                    ],
                  ),
                )
                    : TextField(
                  onChanged: (value) {
                    _new_shares(value);
                  },
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                      icon: Icon(
                        Icons.filter_alt_outlined,
                        color: Colors.white,
                      ),
                      hintText: "Add Amount",
                      hintStyle: TextStyle(color: Colors.white)),
                ),
                actions: <Widget>[
                  isSearching
                      ? IconButton(
                    icon: const Icon(Icons.cancel),
                    onPressed: () {
                      setState(() {
                        isSearching = false;
                      });
                    },
                  )
                      : IconButton(
                    icon: Icon(Icons.filter_list_alt),
                    onPressed: () {
                      setState(() {
                        this.isSearching = true;
                      });
                    },
                  )
                ],
              ),
            ],
          ),
      ),

          Flexible(
            child: GridView.count(
              physics: AlwaysScrollableScrollPhysics(),
              childAspectRatio: 1,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              crossAxisCount: 2,
              padding: const EdgeInsets.fromLTRB(3.0, 12.0, 3.0, 12.0),
              children: <Widget>[
                for (var i = 0; i < this.new_shares.length; i++)if(this.new_shares[i].risk==loggedInUser.choice)ProductBox(name: this.new_shares[i].name.toString(), image: "sensex.png", change: this.new_shares[i].predict.toString()),
                if(loggedInUser.choice!="HIGH")ProductBox(
                  name: "Gold",
                  image: "gold.png",
                  change: indexs.Gold.toString(),
                ),
                if(loggedInUser.choice!="HIGH")const SchemeBox(
                    name: "PPF",
                    rate: "7.1",
                    min: 500,
                    feature: "tax free",
                    requirment: ""
                ),
                //SizedBox(height: 25,width: 20,),
                if(loggedInUser.choice!="HIGH")const SchemeBox(
                    name: "SSA",
                    rate: "7.6",
                    min: 250,
                    feature: "",
                    requirment: "gender female"),
                if(loggedInUser.choice!="HIGH")const SchemeBox(
                    name: "SCSS",
                    rate: "7.4",
                    min: 1000,
                    feature: "",
                    requirment: "age 60+"),
                //SizedBox(height: 25,width: 20,),
                if(loggedInUser.choice!="HIGH")const SchemeBox(
                    name: "MIS",
                    rate: "6.6",
                    min: 1000,
                    feature: "",
                    requirment: ""),
                for (var i = 0; i < coins.length; i++) if(this.coins[i].risk==loggedInUser.choice)ProductBox(name: this.coins[i].name.toString(), image: "sensex.png", change: this.coins[i].predict.toString()),

                //SizedBox(height: 25,width: 20,),







              ],
            ),

    ),
    ],),
    );
  }
}

class ProductBox extends StatelessWidget {
  const ProductBox({
    Key? key,
    required this.name,
    required this.image,
    required this.change,
  }) : super(key: key);
  final String name;
  final String image;
  final String? change;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 35,
      child: Card(
        semanticContainer: true,
        color: Colors.brown.shade300,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 10,
        child: SizedBox(
          height: 30,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(this.name, style: TextStyle(color: Colors.grey.shade50)),
              SizedBox(width: 10,),
              Text(this.change.toString() + "%",
                  style: TextStyle(color: Colors.grey.shade50)),
            ]),),
      ),
    );
  }
}

class SchemeBox extends StatelessWidget {
  const SchemeBox({
    Key? key,
    required this.name,
    required this.rate,
    required this.min,
    required this.feature,
    required this.requirment,
  }) : super(key: key);
  final String name;
  final String rate;
  final int min;
  final String feature;
  final String requirment;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print("touched");
        showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text(
                  this.name,
                  style: TextStyle(color: Colors.black38, fontSize: 22),
                ),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8.0))),
                content: SizedBox(
                  height: 80,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text("Features: "),
                          Text(
                            this.feature,
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Text("Requirments: "),
                          Text(
                            this.requirment,
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Text("Minimum amount: "),
                          Text(
                            this.min.toString(),
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                actions: <Widget>[
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: const Text("Close"),
                  ),
                ],
              );
            });
      },
      child: Container(
        height: 35,
        color: Colors.green,
        child: Card(
          semanticContainer: true,
          color: Colors.brown.shade300,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 10,
          child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(this.name,
                          style: TextStyle(color: Colors.grey.shade50)),
                      SizedBox(width: 10,),
                      Text(this.rate.toString() + "%",
                          style: TextStyle(color: Colors.grey.shade50))
                    ]),

        ),
      ),
    );
  }
}

Future<void> logout(BuildContext context) async
{
  await FirebaseAuth.instance.signOut();
  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoginScreen()));
}

