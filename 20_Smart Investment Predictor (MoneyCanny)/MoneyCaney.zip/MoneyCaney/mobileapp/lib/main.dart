import 'package:flutter/material.dart';
import 'package:mobileapp/screens/index.dart';
import 'package:mobileapp/screens/signup_screen.dart';
import 'screens/login_screen.dart';
import 'package:firebase_core/firebase_core.dart';





Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: const FirebaseOptions(
          appId: '1:589444303259:android:d3ac9bf1c4d039c88d393e',
          apiKey: "AIzaSyAkNrjlxmLuBJN4XR2cEKsnUFqFTK4dCSg",
          messagingSenderId: '589444303259',
          projectId: 'mobileapp-investment'
      )
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'MoneyCanny',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.brown,
      ),
      // A widget which will be started on application startup
      home: LoginScreen(),
    );
  }
}
