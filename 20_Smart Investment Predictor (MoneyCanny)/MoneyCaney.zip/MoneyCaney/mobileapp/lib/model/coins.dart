class CoinsModel {
  String? name;
  String? risk;
  double? predict;


  CoinsModel(
      {this.name, this.predict,this.risk});

  factory CoinsModel.fromJson(dynamic json) {
    return CoinsModel(
      name: "${json['Name']}",
      predict: json['Predict'],
      risk: "${json['Risk']}",
    );
  }

  Map toJson() => {
    "Name": name,
    "Predict": predict,
    "Risk": risk
  };
}