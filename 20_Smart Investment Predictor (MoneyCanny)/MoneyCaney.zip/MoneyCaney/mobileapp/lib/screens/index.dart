import 'dart:convert' as convert;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobileapp/model/index_model.dart';
import 'package:mobileapp/model/coins.dart';


class IndexPage extends StatefulWidget {
  const IndexPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _IndexPageState createState() => _IndexPageState();
}

class _IndexPageState extends State<IndexPage> {
  IndexModel indexs = IndexModel();
  List<CoinsModel> coins = [];
  List<CoinsModel> shares = [];

  @override
  void initState(){
    super.initState();

    http
        .get(Uri.parse(
        'https://script.google.com/macros/s/AKfycbw0agaALb04gfSAQk8Z-5jmDTutPf-gajDPH8_cMfBtVxw6TmBaft8HLxsxsRyvT14m/exec'))
        .then((value) {

      print(convert.jsonDecode(value.body));
      convert.jsonDecode(value.body).forEach((element) {
        print('$element THIS IS NEXT>>>>>>>');
        CoinsModel sharesModel = new CoinsModel();
        sharesModel.name = element['Name'];
        sharesModel.predict = element['Predict'];
        sharesModel.risk = element['Risk'];
        this.shares.add(sharesModel);
      });
    });

    http
        .get(Uri.parse(
        'https://script.google.com/macros/s/AKfycbyeHRXy6aktiOiBx-j5or_ec2wi19WWD5X2OX8pCobrkG4SAl5X_NNzRhAnsrGSdPlH/exec'))
        .then((value) {
          print(value.body);
      convert.jsonDecode(value.body).forEach((element) {
        CoinsModel coinsModel = new CoinsModel();
        coinsModel.name = element['Name'];
        coinsModel.predict = element['Predict'];
        coinsModel.risk = element['Risk'];
        this.coins.add(coinsModel);
      });
    });


    http
        .get(Uri.parse(
            'https://script.google.com/macros/s/AKfycbxu4WFE2wcqFBnEXCjUnBMOE1V0L-CDPt2ZATFHqHEVOG1242h_2eNctQZC4VNDBhs4Iw/exec'))
        .then((value) {
      this.indexs = IndexModel.fromMap(convert.jsonDecode(value.body));
      setState(() {});
    });



  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        backgroundColor: Colors.brown.shade300,
        title: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Text("Indexs and More"),
          GestureDetector(
              onTap: () {
                showDialog(
                    context: context,
                    builder: (context) {
                      return Container(
                          height: 15,
                          child: AlertDialog(
                              content: SizedBox(
                                  height: 70,
                                  child: Column(
                                    children: [
                                      Row(children: [
                                        Text("Todays Sensex can go :"),
                                        SizedBox(width: 15,),
                                        Text((indexs.Sensex.toString())+"%"),
                                      ],),
                                      Row(children: [
                                        Text("Todays IC15 can go :"),
                                        SizedBox(width: 15,),
                                        Text(indexs.Crypto.toString()+"%"),
                                      ],),
                                      Row(children: [
                                        Text("Todays Gold Price can go :"),
                                        SizedBox(width: 15,),
                                        Text(indexs.Gold.toString()+"%"),
                                      ],),
                                    ],
                                  ))));
                    });
              },
              child: Row(
                children: [
                  Image(
                    height:  MediaQuery.of(context).size.height*0.1,
                    width: MediaQuery.of(context).size.width*0.1,
                    image: AssetImage(indexs.Sensex! > 1
                        ? "sensex_g.png"
                        : (indexs.Sensex! < -1
                            ? "sensex_r.png"
                            : "sensex.png")),
                  ),
                  Image(
                    height:  MediaQuery.of(context).size.height*0.1,
                    width: MediaQuery.of(context).size.width*0.1,
                    image: AssetImage(indexs.Crypto! > 2
                        ? "crypto_g.png"
                        : (indexs.Crypto! < -2
                            ? "crypto_r.png"
                            : "crypto.png")),
                  ),
                  Image(
                    height:  MediaQuery.of(context).size.height*0.1,
                    width: MediaQuery.of(context).size.width*0.1,
                    image: AssetImage(indexs.Gold! > 0.75
                        ? "gold_g.png"
                        : (indexs.Gold! < -0.75 ? "gold_r.png" : "gold.png")),
                  ),
                ],
              ),
          ),
        ]),
        centerTitle: true,
      ),
      body: GridView.count(
        childAspectRatio: 1,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        crossAxisCount: 2,
        padding: const EdgeInsets.fromLTRB(3.0, 12.0, 3.0, 12.0),
        children: <Widget>[
          for (var i = 0; i < 28; i++) if(this.coins[i].risk=="MID")ProductBox(name: this.coins[i].name.toString(), image: "sensex.png", change: this.coins[i].predict.toString()),
          for (var i = 0; i < 40; i++) if(this.shares[i].risk=="MID")ProductBox(name: this.shares[i].name.toString(), image: "sensex.png", change: this.shares[i].predict.toString()),

              ProductBox(
                name: "Sensex",
                image: "sensex.png",
                change: indexs.Sensex.toString(),
              ),
              //SizedBox(height: 25,width: 20,),
              ProductBox(
                name: "IC15",
                image: "crypto.png",
                change: indexs.Crypto.toString(),
              ),
              ProductBox(
                name: "Gold",
                image: "gold.png",
                change: indexs.Gold.toString(),
              ),
              //SizedBox(height: 25,width: 20,),
              ProductBox(
                name: "Sen-SGX",
                image: "sensex.png",
                change: indexs.SenSgx.toString(),
              ),



              const SchemeBox(
                  name: "PPF",
                  rate: "7.1",
                  min: "500",
                  feature: "tax free",
                  requirment: ""),
              //SizedBox(height: 25,width: 20,),
              const SchemeBox(
                  name: "SSA",
                  rate: "7.6",
                  min: "250",
                  feature: "",
                  requirment: "gender female"),
              const SchemeBox(
                  name: "SCSS",
                  rate: "7.4",
                  min: "1000",
                  feature: "",
                  requirment: "age 60+"),
              //SizedBox(height: 25,width: 20,),
              const SchemeBox(
                  name: "MIS",
                  rate: "6.6",
                  min: "1000",
                  feature: "",
                  requirment: ""),



        ],
      ),
    );
  }
}

class ProductBox extends StatelessWidget {
  const ProductBox({
    Key? key,
    required this.name,
    required this.image,
    required this.change,
  }) : super(key: key);
  final String name;
  final String image;
  final String? change;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 35,
      child: Card(
        semanticContainer: true,
        color: Colors.brown.shade300,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 10,
        child: SizedBox(
          height: 30,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(this.name, style: TextStyle(color: Colors.grey.shade50)),
              SizedBox(width: 10,),
              Text(this.change.toString() + "%",
                  style: TextStyle(color: Colors.grey.shade50)),
            ]),),
      ),
    );
  }
}

class SchemeBox extends StatelessWidget {
  const SchemeBox({
    Key? key,
    required this.name,
    required this.rate,
    required this.min,
    required this.feature,
    required this.requirment,
  }) : super(key: key);
  final String name;
  final String rate;
  final String min;
  final String feature;
  final String requirment;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print("touched");
        showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text(
                  this.name,
                  style: TextStyle(color: Colors.black38, fontSize: 22),
                ),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8.0))),
                content: SizedBox(
                  height: 80,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text("Features: "),
                          Text(
                            this.feature,
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Text("Requirments: "),
                          Text(
                            this.requirment,
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Text("Minimum amount: "),
                          Text(
                            this.min,
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                actions: <Widget>[
                  FlatButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text("Close"),
                  ),
                ],
              );
            });
      },
      child: Container(
        height: 35,
        child: Card(
          semanticContainer: true,
          color: Colors.brown.shade200,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 10,
          child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(this.name,
                          style: TextStyle(color: Colors.grey.shade50)),
                      SizedBox(width: 10,),
                      Text(this.rate.toString() + "%",
                          style: TextStyle(color: Colors.grey.shade50))
                    ]),

        ),
      ),
    );
  }
}
